/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javamidterm;

/**
 *
 * @author THANH
 */
public class Intern extends Employee{
    
    String Majors;
	String Semester;
	String University_name;
	
	public Intern(int ID,String FullName, String BirthDay, String Phone,String Email,String Majors,String Semester, String University_name)  {
			super(ID,FullName,BirthDay,Phone,Email,"Intern");
			this.Majors = Majors;
			this.Semester = Semester;
			this.University_name = University_name;
	}
	
	public void ShowInfo() {
		super.ShowInfo();
		System.out.println("Majors "+ Majors);
		System.out.println("Semester "+ Semester);
		System.out.println("University_name "+ University_name);
	}
    
}
