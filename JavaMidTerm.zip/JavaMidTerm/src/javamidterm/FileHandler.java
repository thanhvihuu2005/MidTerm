/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javamidterm;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.io.File;

public class FileHandler {
    // Ghi thông tin nhân viên vào file
    public static void writeToFile(ArrayList<Employee> employees, String fileName) {
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(fileName);
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
            objectOutputStream.writeObject(employees);
            objectOutputStream.close();
            fileOutputStream.close();
            System.out.println("Da ghi thong tin nhan vien vao file " + fileName);
        } catch (Exception e) {
            System.out.println("Loi khi luu thong tin nhan vien vao file: " + e.getMessage());
        }
    }

    // Đọc thông tin nhân viên từ file
    public static ArrayList<Employee> readFromFile(String fileName) {
        ArrayList<Employee> employees = new ArrayList<>();
        try {
            FileInputStream fileInputStream = new FileInputStream(fileName);
            ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
            employees = (ArrayList<Employee>) objectInputStream.readObject();
            objectInputStream.close();
            fileInputStream.close();
            System.out.println("Da doc thong tin nhan vien vao file " + fileName);
        } catch (Exception e) {
            System.out.println("Loi khi doc thong tin nhan vien vao file: " + e.getMessage());
        }
        return employees;
    }
}
